﻿using System;
using System.Text;

namespace DimensionsNewAge.Scripts
{
    public class HueWoodConst
    {
        public const int HueNormalWood = 0x000;
        public const int HueFineWood = 0x030;
        public const int HuePoisonWood = 0x03f;
        public const int HueFireWood = 0x020;
    }
}
