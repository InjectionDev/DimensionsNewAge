﻿using System;
using System.Text;

namespace DimensionsNewAge.Scripts
{
    public class HueHideConst
    {

        public const int HueHideCyclops = 0x095;
        public const int HueHideGargoyle = 0x1bb;
        public const int HueHideTerathan = 0x165;
        public const int HueHideDaemon = 0x026;
        public const int HueHideDragon = 0x454;
        public const int HueHideZZ = 0x029;
        public const int HueHideDragonGreen = 0x056;

        //color_hide_daemon    026
        //color_hide_zz        029
        //color_hide_dragon    0454
        //color_hide_terathan    0165
        //color_hide_gargoyle    01bb
        //color_hide_cyclops    095
        //color_hide_dragon_green    056
    }
}
