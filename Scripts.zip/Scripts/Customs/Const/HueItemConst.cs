﻿using System;
using System.Text;

namespace DimensionsNewAge.Scripts
{
    public class HueItemConst
    {
        public const int HueRayBow = 280;
        public const int HuePoisonBow = 57;
        public const int HueAdvancedPoisonBow = 69;
        public const int HueFireBow = 32;
        public const int HueElvenBow = 567;


        public static int HueMagicColorRandom
        { 
            get
            {
                //return HuesMagicColor[new Random().Next(HuesMagicColor.Length)];
                return new Random().Next(1930, 1989);
            }
        }

        public static int HueMustangColorRandom
        {
            get
            {
                return HuesMustangColor[new Random().Next(HuesMustangColor.Length)];
            }
        }

        // Balron DyeTube -> HUES Random().Next(1930, 1989)
        //private static readonly int[] HuesMagicColor = new int[]
        //    {
        //        1152,1153,1974,1973,1962,0x794,0x798,0x7aa,
        //        0x7ac,0x79b,0x79a,0x7a5,0x7a2,0x7a3,0x7a6,0x7a8,0x78a,
        //        0x78c,0x78e,0x78f,0x793,0x788,0x7a9,0x79c,0x79d,0x79e,
        //        0x7ff,0x780,0x782,0x783,0x785,0x786,0x790,0x791,0x796
        //    };

        // Mustang Hue
        private static readonly int[] HuesMustangColor = new int[]
			{
				1109, // Black Mustang
                438, // Crimson Mustang
                796, // SkyGray Mustang
                344, // Wimmimate Mustang
                51, // Pamamino Mustang
                611, // Sky Mustang
                279, // Redroan Mustang
                443, // Chocolate/Roan Mustang
                999 // Grey Mustang
			};

    }
}
