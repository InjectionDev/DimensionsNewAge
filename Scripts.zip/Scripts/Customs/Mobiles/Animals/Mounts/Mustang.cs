using System;
using Server;
using Server.Items;
using Server.Mobiles;

namespace Server.Mobiles
{
	[CorpseName( "a mustang corpse" )]
	public class Mustang : BaseMount
	{
		[Constructable]
		public Mustang() : this( "Mustang" )
		{
		}

		[Constructable]
        public Mustang(string name)
            : base(name, 0x74, 0x3EA7, AIType.AI_Animal, FightMode.Aggressor, 10, 1, 0.2, 0.4)
		{
			BaseSoundID = 0xA8;

			SetStr( 100, 150 );
			SetDex( 50, 60 );
			SetInt( 50, 60 );

			SetHits( 100, 150 );

			SetDamage( 10, 16 );

			SetDamageType( ResistanceType.Physical, 100 );
			//SetDamageType( ResistanceType.Fire, 40 );
			//SetDamageType( ResistanceType.Energy, 20 );

			SetResistance( ResistanceType.Physical, 55, 65 );
			SetResistance( ResistanceType.Fire, 30, 40 );
			SetResistance( ResistanceType.Cold, 30, 40 );
			SetResistance( ResistanceType.Poison, 30, 40 );
			SetResistance( ResistanceType.Energy, 20, 30 );

			SetSkill( SkillName.EvalInt, 10.4, 50.0 );
			SetSkill( SkillName.Magery, 10.4, 50.0 );
			SetSkill( SkillName.MagicResist, 85.3, 100.0 );
			SetSkill( SkillName.Tactics, 97.6, 100.0 );
			SetSkill( SkillName.Wrestling, 80.5, 92.5 );

			Fame = 500;
			Karma = 500;

			VirtualArmor = 60;

			Tamable = true;
			ControlSlots = 1;
			MinTameSkill = 90.1;

            Hue = DimensionsNewAge.Scripts.HueItemConst.HueMustangColorRandom;

            switch (Hue)
            {
                case 0x455:
                    Name = "Black Mustang";
                    break;
                case 0x1b6:
                    Name = "Crimson Mustang";
                    break;
                case 0x31c:
                    Name = "SkyGray Mustang";
                    break;
                case 0x158:
                    Name = "Wimmimate Mustang";
                    break;
                case 0x033:
                    Name = "Pamamino Mustang";
                    break;
                case 0x263:
                    Name = "Sky Mustang";
                    break;
                case 0x279:
                    Name = "Redroan Mustang";
                    break;
                case 0x1bb:
                    Name = "Roan Mustang";
                    break;
                case 0x3e7:
                    Name = "Grey Mustang";
                    break;

                default:
                    Name = "Mustang";
                    break;
            }

            BodyValue = 116;
            ItemID = 16039;

			PackItem( new SulfurousAsh( Utility.RandomMinMax( 3, 5 ) ) );
		}

		public override void GenerateLoot()
		{
			AddLoot( LootPack.Rich );
			AddLoot( LootPack.Average );
			AddLoot( LootPack.LowScrolls );
			AddLoot( LootPack.Potions );
		}

		public override int GetAngerSound()
		{
			if ( !Controlled )
				return 0x16A;

			return base.GetAngerSound();
		}

		public override int Meat{ get{ return 5; } }
		public override int Hides{ get{ return 10; } }
		public override HideType HideType{ get{ return HideType.Barbed; } }
		public override FoodType FavoriteFood{ get{ return FoodType.Meat; } }
		public override bool CanAngerOnTame { get { return true; } }

        public Mustang(Serial serial)
            : base(serial)
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

    [CorpseName("a exotic mustang corpse")]
    public class MustangExotic : BaseMount
    {
        [Constructable]
        public MustangExotic()
            : this("Mustang Exotic")
        {
        }

        [Constructable]
        public MustangExotic(string name)
            : base(name, 0x74, 0x3EA7, AIType.AI_Animal, FightMode.Aggressor, 10, 1, 0.2, 0.4)
        {
            BaseSoundID = 0xA8;

            SetStr(100, 150);
            SetDex(50, 60);
            SetInt(50, 60);

            SetHits(100, 150);

            SetDamage(10, 16);

            SetDamageType(ResistanceType.Physical, 100);
            //SetDamageType( ResistanceType.Fire, 40 );
            //SetDamageType( ResistanceType.Energy, 20 );

            SetResistance(ResistanceType.Physical, 55, 65);
            SetResistance(ResistanceType.Fire, 30, 40);
            SetResistance(ResistanceType.Cold, 30, 40);
            SetResistance(ResistanceType.Poison, 30, 40);
            SetResistance(ResistanceType.Energy, 20, 30);

            SetSkill(SkillName.EvalInt, 10.4, 50.0);
            SetSkill(SkillName.Magery, 10.4, 50.0);
            SetSkill(SkillName.MagicResist, 85.3, 100.0);
            SetSkill(SkillName.Tactics, 97.6, 100.0);
            SetSkill(SkillName.Wrestling, 80.5, 92.5);

            Fame = 500;
            Karma = 500;

            VirtualArmor = 60;

            Tamable = true;
            ControlSlots = 1;
            MinTameSkill = 90.1;

            Hue = DimensionsNewAge.Scripts.HueItemConst.HueMagicColorRandom;

            BodyValue = 116;
            ItemID = 16039;


            PackItem(new SulfurousAsh(Utility.RandomMinMax(3, 5)));
        }

        public override void GenerateLoot()
        {
            AddLoot(LootPack.Rich);
            AddLoot(LootPack.Average);
            AddLoot(LootPack.LowScrolls);
            AddLoot(LootPack.Potions);
        }

        public override int GetAngerSound()
        {
            if (!Controlled)
                return 0x16A;

            return base.GetAngerSound();
        }

        public override int Meat { get { return 5; } }
        public override int Hides { get { return 10; } }
        public override HideType HideType { get { return HideType.Barbed; } }
        public override FoodType FavoriteFood { get { return FoodType.Meat; } }
        public override bool CanAngerOnTame { get { return true; } }

        public MustangExotic(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}