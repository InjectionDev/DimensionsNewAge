﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Server
{
    public static class Logger
    {
        
        private static string filePath = @"Logs\RunUODev.Log.txt";
        private static object objLock = new object();

        public static void LogMessage(string pMessage, string pType)
        {
            string timestamp = string.Format(string.Format("[{0:d2}:{1:d2}] ", DateTime.Now.Hour, DateTime.Now.Minute));

            lock (objLock)
            {
                if (!File.Exists(filePath))
                    File.Create(filePath);

                using (StreamWriter sw = File.AppendText(filePath))
                {
                    sw.WriteLine(timestamp + pType +": "+pMessage);
                }
            }

            Console.WriteLine(timestamp + pType + ": " + pMessage);
        }


    }
}
