﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DimensionsNewAge.Scripts.Customs.Engines
{
    public class EnumEventBase
    {
        public enum EnumEventType
        { 
            TheHunt = 0,
            Survivor = 1
        }
    }
}
