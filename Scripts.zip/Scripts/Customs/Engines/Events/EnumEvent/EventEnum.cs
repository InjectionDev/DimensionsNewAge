﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DimensionsNewAge.Scripts.Customs.Engines.Events.Enum
{
    public class EventEnum
    {

        public enum EventName
        {
            TheHunt = 0,
            Survivor = 1,
            FreeForAll = 2
        }


    }
}
