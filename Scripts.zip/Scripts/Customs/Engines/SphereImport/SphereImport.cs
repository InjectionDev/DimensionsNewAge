﻿using System;
using System.Collections;
using System.IO;
using Server;
using Server.Network;
using Server.Targeting;
using Server.Factions;
using Server.Commands;
using System.Collections.Generic;

using Server.Mobiles;
using Server.Regions;
using Server.Gumps;
using Server.Items;

namespace DimensionsNewAge.Scripts.Customs.Engines.SphereImport
{
    public class SphereImport
    {

        private static string filePath = @"C:\SphereSave\";

        private static string accName = string.Empty;
        private static string charID = string.Empty;
        private static string bankboxID = string.Empty;
        private static string backpackID = string.Empty;
        private static string accDestinationID;

        private static Mobile caller;
        private static List<string> objectStringList = new List<string>();
        private static List<SphereItemClass> sphereItensListToAcc = new List<SphereItemClass>();

        public static void Initialize()
        {
            CommandSystem.Register("sphereimport", AccessLevel.Developer, new CommandEventHandler(SphereImport_OnCommand));
        }

        public static void SphereImport_OnCommand(CommandEventArgs e)
        {

            caller = e.Mobile;

            if (string.IsNullOrEmpty(e.Arguments[0]))
            {
                e.Mobile.SendMessage("ACC INVALIDA");
                return;
            }

            accName = e.Arguments[0];

            if (e.Arguments.Length == 2)
                accDestinationID = e.Arguments[1];

            FindAccount();

            if (string.IsNullOrEmpty(charID))
            {
                caller.SendMessage("ACC ID Nao localizado!");
                return;
            }

            FindBankBox();

            if (string.IsNullOrEmpty(backpackID))
            {
                caller.SendMessage("BACKPACK ID Nao localizado!");
                return;
            }
            if (string.IsNullOrEmpty(bankboxID))
            {
                caller.SendMessage("BANKBOX ID Nao localizado!");
                return;
            }

            sphereItensListToAcc.Clear();

            FindItens();

            caller.SendMessage("Total Itens Localizados: " + sphereItensListToAcc.Count);

            CreateItens();

            caller.SendMessage("Itens Importados na sua Backpack. Fim");
        }

        private static void CreateItens()
        {
            Bag bagItens = new Bag();
            bagItens.Name = "Itens de " + accName;

            Bag bagOres = new Bag();
            Bag bagIngots = new Bag();
            Bag bagArmor = new Bag();
            Bag bagWeapon = new Bag();
            Bag bagMount = new Bag();
            Bag bagOther = new Bag();

            foreach (SphereItemClass sphereItem in sphereItensListToAcc)
            {
                object item = RewardUtil.CreateRewardInstance(sphereItem.itemType);

                if (item is Item)
                {
                    ((Item)item).Amount = sphereItem.qtAmount;
                }

                if (item is BaseOre)
                {
                    bagOres.DropItem((Item)item);
                }
                else if (item is BaseIngot)
                {
                    bagIngots.DropItem((Item)item);
                }
                else if (item is BaseWeapon)
                {
                    bagWeapon.DropItem((Item)item);
                }
                else if (item is BaseArmor)
                {
                    bagArmor.DropItem((Item)item);
                }
                else if (item is BaseCreature)
                {
                    ShrinkItem shrunkenPet = new ShrinkItem((BaseCreature)item);
                    bagMount.DropItem(shrunkenPet);
                }
                else
                {
                    bagOther.DropItem((Item)item);
                }
            }

            bagItens.DropItem(bagOres);
            bagItens.DropItem(bagIngots);
            bagItens.DropItem(bagArmor);
            bagItens.DropItem(bagWeapon);
            bagItens.DropItem(bagMount);
            bagItens.DropItem(bagOther);

            caller.Backpack.DropItem(bagItens);
        }

        private static bool FindBankInList()
        {
            bool isBank = false;
            bool isCorrectBank = false;
            foreach (string line in objectStringList)
            {
                if (line.Contains("i_bankbox"))
                {
                    isBank = true;
                    break;
                }
            }

            if (isBank == false)
                return false;


            foreach (string line in objectStringList)
            {
                if (line.StartsWith("CONT="))
                {
                    if (line.Replace("CONT=", "").Trim() == charID.Trim())
                    {
                        isCorrectBank = true;
                        break;
                    }
                }
            }

            if (isCorrectBank == false)
                return false;

            foreach (string line in objectStringList)
            {
                if (line.StartsWith("SERIAL="))
                {
                    bankboxID = line.Replace("SERIAL=", "");
                    caller.SendMessage(string.Format("BankBox localizada! Serial: {0}", bankboxID));
                    return true;
                }
            }

            return false;
        }

        private static bool FindBackPackInList()
        {
            bool isBackPack = false;
            bool isCorrectBackPack = false;
            foreach (string line in objectStringList)
            {
                if (line.Contains("i_backpack"))
                {
                    isBackPack = true;
                    break;
                }
            }

            if (isBackPack == false)
                return false;


            foreach (string line in objectStringList)
            {
                if (line.StartsWith("CONT="))
                {
                    if (line.Replace("CONT=", "").Trim() == charID.Trim())
                    {
                        isCorrectBackPack = true;
                        break;
                    }
                }
            }

            if (isCorrectBackPack == false)
                return false;

            foreach (string line in objectStringList)
            {
                if (line.StartsWith("SERIAL="))
                {
                    backpackID = line.Replace("SERIAL=", "");
                    caller.SendMessage(string.Format("BackPack localizada! Serial: {0}", backpackID));
                    return true;
                }
            }

            return false;
        }

        private static void FindItensInList()
        {
            bool isItem = false;
            bool isCorrectItem = false;
            SphereItemClass currentSphereItem = null;

            foreach (string line in objectStringList)
            {
                if (line.StartsWith("[WI"))
                {
                    foreach (SphereItemClass sphereItem in SphereItens.SphereItensList)
                    {
                        if (line.ToLower().Contains(sphereItem.sphereID.ToLower()))
                        {
                            isItem = true;
                            currentSphereItem = sphereItem;
                            break;
                        }
                    }
                }
            }

            if (isItem == false)
                return;

            foreach (string line in objectStringList)
            {
                if (line.StartsWith("CONT="))
                {
                    if (line.Replace("CONT=", "").Trim() == charID.Trim() ||
                        line.Replace("CONT=", "").Trim() == backpackID.Trim() ||
                        line.Replace("CONT=", "").Trim() == bankboxID.Trim())
                    {
                        isCorrectItem = true;
                        break;
                    }
                }
            }

            if (isCorrectItem == false)
                return;

            
            foreach (string line in objectStringList)
            {
                if (line.StartsWith("AMOUNT="))
                {
                    currentSphereItem.qtAmount = Convert.ToInt32(line.Replace("AMOUNT=", ""));
                }
            }

            sphereItensListToAcc.Add(currentSphereItem);
        }

        private static void FindItens()
        {
            string[] files = Directory.GetFiles(filePath);

            Console.WriteLine(string.Format("Buscando Itens em {0} arquivos", files.Length));

            foreach (string file in files)
            {

                try
                {
                    using (StreamReader sr = new StreamReader(file))
                    {
                        String line;

                        while ((line = sr.ReadLine()) != null)
                        {
                            if (line.StartsWith("[") && line.EndsWith("]"))
                            {
                                if (objectStringList.Count > 0)
                                {
                                    FindItensInList();

                                    objectStringList.Clear();
                                }
                            }

                            objectStringList.Add(line);
                        }
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("Erro ao ler arquivo. " + file + " - " + e.Message);
                }
            }

            Console.WriteLine(string.Format("NAO Achou ACC {0}.", accName));
        }

        private static void FindBankBox()
        {
            string[] files = Directory.GetFiles(filePath);

            Console.WriteLine(string.Format("Buscando BankBox em {0} arquivos", files.Length));

            foreach (string file in files)
            {

                try
                {
                    using (StreamReader sr = new StreamReader(file))
                    {
                        String line;

                        while ((line = sr.ReadLine()) != null)
                        {
                            if (line.StartsWith("[") && line.EndsWith("]"))
                            {
                                if (objectStringList.Count > 0)
                                {
                                    FindBankInList();
                                    FindBackPackInList();

                                    objectStringList.Clear();
                                }
                            }

                            objectStringList.Add(line);
                        }
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("Erro ao ler arquivo. " + file + " - " + e.Message);
                }
            }

            Console.WriteLine(string.Format("NAO Achou ACC {0}.", accName));
        }

        private static void FindAccount()
        {
            string[] files = Directory.GetFiles(filePath);

            Console.WriteLine(string.Format("Buscando ACCOUNT em {0} arquivos", files.Length));

            foreach (string file in files)
            {

                try
                {
                    using (StreamReader sr = new StreamReader(file))
                    {
                        String line;

                        while ((line = sr.ReadLine()) != null)
                        {
                            if (line.StartsWith("[") && line.EndsWith("]"))
                            {
                                if (objectStringList.Count > 0)
                                {
                                    if (FindAccountInList())
                                    {
                                        objectStringList.Clear();
                                        return;
                                    }

                                    objectStringList.Clear();
                                }
                            }

                            objectStringList.Add(line);
                        }
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("Erro ao ler arquivo. " + file + " - " + e.Message);
                }
            }

            Console.WriteLine(string.Format("NAO Achou ACC {0}.", accName));
        }

        private static void SetSkill(List<string> pObjectStringList)
        {
            if (string.IsNullOrEmpty(accDestinationID))
                return;

            Mobile destMobile = null;
            foreach (Mobile mobile in World.Mobiles.Values)
            {
                if (mobile.Serial.Value == Convert.ToInt32(accDestinationID))
                    destMobile = mobile;
            }

            if (destMobile == null)
                return;

            foreach (string line in objectStringList)
            {
                if (line.StartsWith("OSTR="))
                    destMobile.Str = Convert.ToInt32(line.Replace("OSTR=", ""));
                if (line.StartsWith("OINT="))
                    destMobile.Int = Convert.ToInt32(line.Replace("OINT=", ""));
                if (line.StartsWith("ODEX="))
                    destMobile.Dex = Convert.ToInt32(line.Replace("ODEX=", ""));

                if (line.StartsWith("Alchemy="))
                    destMobile.Skills.Alchemy.Base = Convert.ToInt32(line.Replace("Alchemy=", ""));
                if (line.StartsWith("Anatomy="))
                    destMobile.Skills.Anatomy.Base = Convert.ToInt32(line.Replace("Anatomy=", ""));
                if (line.StartsWith("AnimalLore="))
                    destMobile.Skills.AnimalLore.Base = Convert.ToInt32(line.Replace("AnimalLore=", ""));
                if (line.StartsWith("ItemID="))
                    destMobile.Skills.ItemID.Base = Convert.ToInt32(line.Replace("ItemID=", ""));
                if (line.StartsWith("ArmsLore="))
                    destMobile.Skills.ArmsLore.Base = Convert.ToInt32(line.Replace("ArmsLore=", ""));
                if (line.StartsWith("Parrying="))
                    destMobile.Skills.Parry.Base = Convert.ToInt32(line.Replace("Parrying=", ""));
                if (line.StartsWith("Begging="))
                    destMobile.Skills.Begging.Base = Convert.ToInt32(line.Replace("Begging=", ""));
                if (line.StartsWith("Blacksmithing="))
                    destMobile.Skills.Blacksmith.Base = Convert.ToInt32(line.Replace("Blacksmithing=", ""));
                if (line.StartsWith("Bowcraft="))
                    destMobile.Skills.Fletching.Base = Convert.ToInt32(line.Replace("Bowcraft=", ""));
                if (line.StartsWith("Peacemaking="))
                    destMobile.Skills.Peacemaking.Base = Convert.ToInt32(line.Replace("Peacemaking=", ""));
                if (line.StartsWith("Camping="))
                    destMobile.Skills.Camping.Base = Convert.ToInt32(line.Replace("Camping=", ""));
                if (line.StartsWith("Carpentry="))
                    destMobile.Skills.Carpentry.Base = Convert.ToInt32(line.Replace("Carpentry=", ""));
                if (line.StartsWith("Cartography="))
                    destMobile.Skills.Cartography.Base = Convert.ToInt32(line.Replace("Cartography=", ""));
                if (line.StartsWith("Cooking="))
                    destMobile.Skills.Cooking.Base = Convert.ToInt32(line.Replace("Cooking=", ""));
                if (line.StartsWith("DetectingHidden="))
                    destMobile.Skills.DetectHidden.Base = Convert.ToInt32(line.Replace("DetectingHidden=", ""));
                if (line.StartsWith("Enticement="))
                    destMobile.Skills.Discordance.Base = Convert.ToInt32(line.Replace("Enticement=", ""));
                if (line.StartsWith("EvaluatingIntel="))
                    destMobile.Skills.EvalInt.Base = Convert.ToInt32(line.Replace("EvaluatingIntel=", ""));
                if (line.StartsWith("Healing="))
                    destMobile.Skills.Healing.Base = Convert.ToInt32(line.Replace("Healing=", ""));
                if (line.StartsWith("Fishing="))
                    destMobile.Skills.Fishing.Base = Convert.ToInt32(line.Replace("Fishing=", ""));
                if (line.StartsWith("Forensics="))
                    destMobile.Skills.Forensics.Base = Convert.ToInt32(line.Replace("Forensics=", ""));
                if (line.StartsWith("Herding="))
                    destMobile.Skills.Herding.Base = Convert.ToInt32(line.Replace("Herding=", ""));
                if (line.StartsWith("Hiding="))
                    destMobile.Skills.Hiding.Base = Convert.ToInt32(line.Replace("Hiding=", ""));
                if (line.StartsWith("Provocation="))
                    destMobile.Skills.Provocation.Base = Convert.ToInt32(line.Replace("Provocation=", ""));
                if (line.StartsWith("Inscription="))
                    destMobile.Skills.Inscribe.Base = Convert.ToInt32(line.Replace("Inscription=", ""));
                if (line.StartsWith("LockPicking="))
                    destMobile.Skills.Lockpicking.Base = Convert.ToInt32(line.Replace("LockPicking=", ""));
                if (line.StartsWith("Magery="))
                    destMobile.Skills.Magery.Base = Convert.ToInt32(line.Replace("Magery=", ""));
                if (line.StartsWith("MagicResistance="))
                    destMobile.Skills.MagicResist.Base = Convert.ToInt32(line.Replace("MagicResistance=", ""));
                if (line.StartsWith("Tactics="))
                    destMobile.Skills.Tactics.Base = Convert.ToInt32(line.Replace("Tactics=", ""));
                if (line.StartsWith("Snooping="))
                    destMobile.Skills.Snooping.Base = Convert.ToInt32(line.Replace("Snooping=", ""));
                if (line.StartsWith("Musicianship="))
                    destMobile.Skills.Musicianship.Base = Convert.ToInt32(line.Replace("Musicianship=", ""));
                if (line.StartsWith("Poisoning="))
                    destMobile.Skills.Poisoning.Base = Convert.ToInt32(line.Replace("Poisoning=", ""));
                if (line.StartsWith("Archery="))
                    destMobile.Skills.Archery.Base = Convert.ToInt32(line.Replace("Archery=", ""));
                if (line.StartsWith("SpiritSpeak="))
                    destMobile.Skills.SpiritSpeak.Base = Convert.ToInt32(line.Replace("SpiritSpeak=", ""));
                if (line.StartsWith("Stealing="))
                    destMobile.Skills.Stealing.Base = Convert.ToInt32(line.Replace("Stealing=", ""));
                if (line.StartsWith("Tailoring="))
                    destMobile.Skills.Tailoring.Base = Convert.ToInt32(line.Replace("Tailoring=", ""));
                if (line.StartsWith("Taming="))
                    destMobile.Skills.AnimalTaming.Base = Convert.ToInt32(line.Replace("Taming=", ""));
                if (line.StartsWith("TasteID="))
                    destMobile.Skills.TasteID.Base = Convert.ToInt32(line.Replace("TasteID=", ""));
                if (line.StartsWith("Tinkering="))
                    destMobile.Skills.Tinkering.Base = Convert.ToInt32(line.Replace("Tinkering=", ""));
                if (line.StartsWith("Tracking="))
                    destMobile.Skills.Tracking.Base = Convert.ToInt32(line.Replace("Tracking=", ""));
                if (line.StartsWith("Veterinary="))
                    destMobile.Skills.Veterinary.Base = Convert.ToInt32(line.Replace("Veterinary=", ""));
                if (line.StartsWith("Swordsmanship="))
                    destMobile.Skills.Swords.Base = Convert.ToInt32(line.Replace("Swordsmanship=", ""));
                if (line.StartsWith("Macefighting="))
                    destMobile.Skills.Macing.Base = Convert.ToInt32(line.Replace("Macefighting=", ""));
                if (line.StartsWith("Fencing="))
                    destMobile.Skills.Fencing.Base = Convert.ToInt32(line.Replace("Fencing=", ""));
                if (line.StartsWith("Wrestling="))
                    destMobile.Skills.Wrestling.Base = Convert.ToInt32(line.Replace("Wrestling=", ""));
                if (line.StartsWith("Lumberjacking="))
                    destMobile.Skills.Lumberjacking.Base = Convert.ToInt32(line.Replace("Lumberjacking=", ""));
                if (line.StartsWith("Mining="))
                    destMobile.Skills.Mining.Base = Convert.ToInt32(line.Replace("Mining=", ""));
                if (line.StartsWith("Meditation="))
                    destMobile.Skills.Meditation.Base = Convert.ToInt32(line.Replace("Meditation=", ""));
                if (line.StartsWith("Stealth="))
                    destMobile.Skills.Stealth.Base = Convert.ToInt32(line.Replace("Stealth=", ""));
                if (line.StartsWith("RemoveTrap="))
                    destMobile.Skills.RemoveTrap.Base = Convert.ToInt32(line.Replace("RemoveTrap=", ""));
               
            }
        }

        private static bool FindAccountInList()
        {
            bool isAccount = false;
            bool isCorrectAccount = false;
            foreach (string line in objectStringList)
            {
                if (line.StartsWith("[WC"))
                {
                    isAccount = true;
                    break;
                }
            }

            if (isAccount == false)
                return false;


            foreach (string line in objectStringList)
            {
                if (line.StartsWith("ACCOUNT="))
                {
                    if (line.Replace("ACCOUNT=", "").Trim() == accName.Trim())
                    {
                        isCorrectAccount = true;
                        break;
                    }
                }
            }

            if (isCorrectAccount == false)
                return false;

            foreach (string line in objectStringList)
            {
                if (line.StartsWith("SERIAL="))
                {
                    charID = line.Replace("SERIAL=", "");
                    caller.SendMessage(string.Format("Account {0} localizada! Serial: {1}", accName, charID));
                }
            }

            SetSkill(objectStringList);

            if (string.IsNullOrEmpty(charID))
                return false;
            else
                return true;
        }




    }
}
